#include <stdio.h>

int t = 3;


int
main (void)
{
  printf("hello world\n");
  return 0;
}
